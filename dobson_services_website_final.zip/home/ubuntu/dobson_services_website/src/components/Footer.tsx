export default function Footer() {
  return (
    <footer className="bg-gray-700 text-white p-8 mt-12 text-center">
      <div className="container mx-auto">
        <p className="mb-2">&copy; {new Date().getFullYear()} Dobson Services. All rights reserved.</p>
        <p className="text-sm mb-1">
          <a href="mailto:info@dobson-services.com" className="hover:text-gray-300 transition-colors">
            info@dobson-services.com
          </a>
        </p>
        {/* Placeholder for Privacy Policy link */}
        {/* <p className="text-sm">
          <Link href="/privacy-policy" className="hover:text-gray-300 transition-colors">
            Privacy Policy
          </Link>
        </p> */}
      </div>
    </footer>
  );
}

