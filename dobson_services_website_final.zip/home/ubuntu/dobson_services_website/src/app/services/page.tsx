import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Our BIM Services | Dobson Services",
  description: "Explore the comprehensive range of Building Information Modeling (BIM) services offered by Dobson Services, tailored to optimize your projects.",
};

const SectionTitle = ({ children }: { children: React.ReactNode }) => (
  <h2 className="text-3xl font-semibold mb-8 text-gray-800 pt-8 first:pt-0">{children}</h2>
);

interface ServiceCardProps {
  title: string;
  description: string;
  benefits: string[];
  // icon?: React.ReactNode; // Placeholder for actual icon components
}

const ServiceCard = ({ title, description, benefits }: ServiceCardProps) => (
  <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow flex flex-col">
    {/* Icon placeholder - to be replaced with actual icons */}
    {/* <div className="text-blue-500 mb-4 text-4xl self-center">{icon || <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12"><path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" /></svg>}</div> */}
    <h3 className="text-xl font-semibold text-indigo-700 mb-3">{title}</h3>
    <p className="text-gray-600 mb-4 text-sm leading-relaxed flex-grow">{description}</p>
    <div>
      <h4 className="text-md font-semibold text-gray-700 mb-2">Key Benefits:</h4>
      <ul className="list-disc list-inside space-y-1 pl-4 text-sm text-gray-600 leading-relaxed">
        {benefits.map((benefit, index) => (
          <li key={index}>{benefit}</li>
        ))}
      </ul>
    </div>
  </div>
);

const servicesData: ServiceCardProps[] = [
  {
    title: "Data Management",
    description: "We establish systematic organization, storage, and control of all project information within a BIM framework. Our comprehensive data management solutions ensure your project data is accessible, accurate, secure, and serves as a single source of truth, enabling seamless collaboration and informed decision-making throughout the project lifecycle.",
    benefits: [
      "Centralized information repository, eliminating data silos.",
      "Enhanced data integrity, quality, and consistency.",
      "Improved collaboration with real-time information sharing.",
      "Efficient information retrieval and analysis.",
      "Comprehensive audit trails and robust version control."
    ]
  },
  {
    title: "Architectural BIM Modeling",
    description: "Our team creates detailed, information-rich 3D architectural models that form the foundation for coordinated building design and construction. We translate architectural concepts into intelligent BIM models that enhance visualization, improve design coordination, and ensure accurate documentation from initial concept to final handover.",
    benefits: [
      "Enhanced design visualization and clearer communication of intent.",
      "Improved coordination with structural and MEP disciplines, reducing clashes.",
      "Accurate, automatically generated drawings, schedules, and quantity takeoffs.",
      "Facilitates design optimization through daylighting, energy, and space analyses.",
      "Streamlined design revisions with parametric modeling capabilities."
    ]
  },
  {
    title: "HVAC BIM Modeling",
    description: "We provide comprehensive 3D modeling and analysis for Heating, Ventilation, and Air Conditioning (HVAC) systems. Our detailed HVAC BIM models optimize system performance, energy efficiency, and spatial coordination, ensuring comfortable indoor environments and reduced operational costs through precise sizing and efficient routing.",
    benefits: [
      "Precise system sizing and performance analysis based on accurate load calculations.",
      "Comprehensive clash detection and coordination with other building systems.",
      "Optimized duct and pipe routing, minimizing materials and pressure drops.",
      "Enhanced energy efficiency analysis and support for sustainability goals.",
      "Detailed fabrication and installation documentation for streamlined execution."
    ]
  },
  {
    title: "Cost Estimation (5D BIM)",
    description: "Leverage the power of 5D BIM for accurate, data-driven cost projections. We integrate cost data directly with the BIM model, enabling real-time feedback on budget implications of design changes, precise quantity takeoffs, and improved cost forecasting throughout all project phases.",
    benefits: [
      "Increased accuracy in quantity takeoffs, eliminating manual errors.",
      "Real-time cost feedback during design, facilitating value-based decisions.",
      "Improved cost forecasting and cash flow management.",
      "Enhanced value engineering by quickly analyzing cost implications of options.",
      "Comprehensive and transparent cost documentation."
    ]
  },
  {
    title: "Quality Control of Construction and Operation",
    description: "Our BIM-based quality control services ensure that construction and operational phases align with design intent and quality standards. We utilize the BIM model for precise verification, clash detection, progress tracking, and streamlined commissioning, leading to higher quality outcomes and efficient facility management.",
    benefits: [
      "Precise verification of construction against design intent.",
      "Proactive clash detection and resolution before issues arise on site.",
      "Enhanced construction documentation and real-time progress tracking.",
      "Streamlined commissioning and handover processes.",
      "Continuous performance monitoring capabilities for facility operations."
    ]
  },
  {
    title: "Digital Construction",
    description: "We facilitate the transition to a fully digital construction environment. This includes advanced construction planning and simulation (4D BIM), improved site logistics, enhanced prefabrication strategies, and real-time progress tracking, ensuring a seamless flow of information from design to the field.",
    benefits: [
      "Advanced construction planning and visual timeline simulation (4D BIM).",
      "Improved site logistics and optimized resource management.",
      "Enhanced support for prefabrication and modular construction.",
      "Real-time progress tracking and reporting against the schedule.",
      "Seamless information flow between office and field teams."
    ]
  },
  {
    title: "Point Cloud to BIM Modeling",
    description: "We transform raw point cloud data from laser scans into accurate, intelligent BIM models. This service is crucial for renovation, retrofit, and as-built documentation projects, providing a precise digital representation of existing conditions for informed design and construction decisions.",
    benefits: [
      "Highly accurate as-built documentation of existing structures.",
      "Comprehensive spatial context for renovation and retrofit planning.",
      "Non-intrusive data capture process, minimizing disruption.",
      "Enhanced visualization and communication of existing conditions.",
      "Reduced need for extensive field verification."
    ]
  },
  {
    title: "BIM Software Development & Customization",
    description: "Dobson Services develops custom BIM software solutions, plugins, and automations to address unique project requirements and optimize specific workflows. If standard tools don’t meet your needs, our development team can create tailored applications to enhance productivity and innovation.",
    benefits: [
      "Automated workflow optimization for repetitive or complex tasks.",
      "Specialized functionality tailored to unique project or company needs.",
      "Enhanced data exchange and integration between different software platforms.",
      "Standardized process implementation across your teams.",
      "Competitive advantage through innovative, custom BIM tools."
    ]
  },
  {
    title: "Revit Model Development from 2D Drawings",
    description: "We expertly convert traditional 2D CAD drawings or paper-based plans into intelligent, data-rich 3D Revit models. This service revitalizes legacy documentation, enabling enhanced visualization, improved coordination, and the application of modern BIM workflows to existing designs or renovation projects.",
    benefits: [
      "Transforms legacy 2D data into intelligent, usable 3D BIM models.",
      "Enhanced information accessibility and usability for existing designs.",
      "Improved visualization and understanding of complex 2D information.",
      "Facilitates efficient renovation, retrofit, and facility management projects.",
      "Preserves design intent while adding the benefits of BIM functionality."
    ]
  },
  {
    title: "Structural BIM Modeling & Analysis",
    description: "Our structural BIM services provide detailed 3D modeling of structural systems and integration with analysis software. We create accurate structural models that facilitate design optimization, ensure stability and safety, and improve coordination with architectural and MEP disciplines.",
    benefits: [
      "Seamless integration of structural design and analytical models.",
      "Comprehensive simulation capabilities for structural performance.",
      "Optimized structural solutions for material efficiency and constructability.",
      "Enhanced visualization of complex structural behavior and components.",
      "Improved coordination with other disciplines to avoid clashes."
    ]
  },
  {
    title: "Electromechanical (MEP) Systems BIM",
    description: "We offer specialized BIM services for Mechanical, Electrical, and Plumbing (MEP) systems. Our detailed MEP models ensure accurate system sizing, clash-free routing, and coordinated layouts, leading to efficient installations, optimized performance, and easier maintenance.",
    benefits: [
      "Comprehensive coordination of all MEP systems with structure and architecture.",
      "Accurate load calculations and precise system sizing.",
      "Enhanced visualization of complex MEP layouts and equipment.",
      "Streamlined generation of installation drawings and documentation.",
      "Improved planning for system maintenance and accessibility."
    ]
  },
  {
    title: "Communication and Low-Voltage Systems BIM",
    description: "Our BIM services extend to the detailed modeling of communication, security, and other low-voltage systems. We ensure integrated planning for pathways, equipment rooms, and device placement, supporting smart building initiatives and future-ready infrastructure.",
    benefits: [
      "Integrated system planning and coordination for all low-voltage infrastructure.",
      "Comprehensive pathway management for cabling and conduits.",
      "Optimization of equipment room layouts and space allocation.",
      "Enhanced security system integration and device placement.",
      "Future-ready infrastructure planning for technological advancements."
    ]
  },
  {
    title: "Plumbing and Drainage Systems BIM",
    description: "We provide precise BIM modeling for plumbing and drainage systems, ensuring efficient layouts, accurate sizing, and clash-free installations. Our services include gravity flow analysis and support for water conservation strategies, contributing to sustainable and effective system design.",
    benefits: [
      "Precise system sizing and optimized layout for efficient flow.",
      "Comprehensive clash detection with other building components.",
      "Gravity flow analysis and optimization for drainage systems.",
      "Support for water conservation analysis and sustainable design.",
      "Enhanced system documentation for installation and maintenance."
    ]
  },
  {
    title: "Interoperability Management",
    description: "We ensure seamless data exchange and collaboration across different software platforms and project phases. Our interoperability management services focus on utilizing open standards (like IFC) and robust workflows to preserve data integrity and facilitate effective communication among all stakeholders, regardless of the tools they use.",
    benefits: [
      "Seamless cross-platform collaboration using openBIM standards.",
      "Preserved data integrity throughout the entire project lifecycle.",
      "Enhanced multidisciplinary coordination and information sharing.",
      "Optimized information exchange with external stakeholders and systems.",
      "Future-proofed building information for long-term usability."
    ]
  },
  {
    title: "BIM Scientific and Educational Activities",
    description: "Dobson Services is committed to advancing BIM knowledge and expertise within the industry. We engage in scientific research, partner with universities, and offer specialized BIM training programs, certification preparation, and implementation workshops led by our expert instructors to empower your teams.",
    benefits: [
      "Access to cutting-edge BIM knowledge and research.",
      "Customized BIM training programs tailored to your team’s needs.",
      "Preparation for industry-recognized BIM certifications.",
      "Practical implementation workshops for hands-on learning.",
      "Proficiency development in leading BIM software for design, analysis, and management."
    ]
  },
  {
    title: "Engineering and Manufacturing Solutions",
    description: "Dobson Services helps you turn innovative ideas into reality. We specialize in creating detailed, visual 3D models that are optimized and print-ready for prototyping, custom component manufacturing, or prefabrication. Our expertise bridges the gap between digital design and physical production, enabling rapid iteration and efficient manufacturing workflows.",
    benefits: [
      "Transform conceptual ideas into tangible, manufacturable 3D models.",
      "Accelerate prototyping and product development cycles.",
      "Optimize designs for 3D printing and other manufacturing processes.",
      "Improve accuracy and reduce waste in fabrication.",
      "Facilitate the creation of custom components and prefabricated assemblies."
    ]
  }
];

export default function ServicesPage() {
  return (
    <div className="space-y-10 bg-white p-6 md:p-10 rounded-lg shadow-xl">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold text-indigo-700 mb-4">Our Comprehensive BIM Services</h1>
        <p className="text-lg text-gray-700 max-w-3xl mx-auto leading-relaxed">
          Dobson Services offers a full spectrum of Building Information Modeling (BIM) solutions designed to optimize every stage of your project lifecycle. Our expert team leverages advanced BIM technologies and proven methodologies to deliver precision, efficiency, and value. We tailor our services to meet your specific project requirements, ensuring you achieve your goals and maximize your return on investment.
        </p>
      </header>

      <section>
        <SectionTitle>Our BIM Service Offerings</SectionTitle>
        <p className="text-lg text-gray-700 mb-10 leading-relaxed">
          Below is a detailed overview of the BIM services we provide. Each service is designed to address specific challenges and deliver tangible benefits to your construction and engineering projects.
        </p>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {servicesData.map((service) => (
            <ServiceCard key={service.title} {...service} />
          ))}
        </div>
      </section>

      <section className="mt-16 py-12 bg-gray-100 rounded-lg shadow-md">
        <div className="container mx-auto text-center px-4">
          <h2 className="text-3xl font-semibold text-gray-800 mb-4">Tailored Solutions for Your Unique Needs</h2>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto mb-8 leading-relaxed">
            At Dobson Services, we understand that every project is unique. While we offer a comprehensive range of standardized BIM services, we excel at customizing our solutions to meet your specific challenges and objectives. We work closely with you to develop a BIM strategy that aligns perfectly with your project goals, ensuring maximum impact and value.
          </p>
          <Link href="/contact" className="bg-indigo-600 text-white font-semibold py-3 px-8 rounded-lg hover:bg-indigo-700 transition-colors text-lg shadow-md">
            Contact Dobson Services Today
          </Link>
        </div>
      </section>
    </div>
  );
}

