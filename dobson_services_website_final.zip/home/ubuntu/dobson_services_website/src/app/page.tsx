import Link from 'next/link';

export default function HomePage() {
  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-20 px-4 text-center rounded-lg shadow-xl">
        <div className="container mx-auto">
          <h1 className="text-5xl font-bold mb-6">Transforming Construction with Expert BIM Solutions</h1>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Dobson Services, a specialized division of Dobson Consulting, empowers construction and engineering projects across Switzerland, the CIS region, and Europe with cutting-edge Building Information Modeling (BIM) solutions. We are dedicated to helping our clients harness the full potential of BIM technology to achieve superior efficiency, reduce costs, and enhance collaboration from concept to completion.
          </p>
          <Link href="/services" className="bg-white text-indigo-700 font-semibold py-3 px-8 rounded-lg hover:bg-gray-100 transition-colors text-lg shadow-md">
            Discover Our Services
          </Link>
        </div>
      </section>

      {/* Section 1: Who We Are */}
      <section className="py-12 bg-gray-50 rounded-lg shadow-lg">
        <div className="container mx-auto text-center px-4">
          <h2 className="text-3xl font-semibold mb-6 text-gray-800">Who We Are</h2>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto mb-4">
            Dobson Services, proudly part of the esteemed Dobson Consulting group, is a Switzerland-based firm at the forefront of BIM innovation. Our core mission is to deliver customer-centric BIM solutions that address the unique challenges of modern construction and engineering. We combine Swiss precision with deep market knowledge, particularly in facilitating business expansion into the CIS region and supporting Central Asian partners in European markets. Our expertise lies in bridging opportunities and ensuring successful, sustainable growth for our clients through the strategic implementation of BIM.
          </p>
          <Link href="/about" className="text-indigo-600 hover:text-indigo-800 font-medium transition-colors">
            Learn more about our journey and values &rarr;
          </Link>
        </div>
      </section>

      {/* Section 2: How We Help */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-semibold mb-10 text-center text-gray-800">How We Help</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
              {/* Placeholder for Icon */}
              <div className="text-blue-500 mb-4 text-4xl"> {/* Icon placeholder style */}
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 mx-auto">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-700">Increased Efficiency</h3>
              <p className="text-gray-600">Streamline workflows, automate tasks, and optimize resources with intelligent BIM processes for faster project delivery.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
              {/* Placeholder for Icon */}
              <div className="text-green-500 mb-4 text-4xl">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 mx-auto">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.75c0 5.592 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.57-.598-3.75h-.152c-3.196 0-6.1-1.248-8.25-3.286zm0 13.036h.008v.016h-.008v-.016z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-700">Reduced Costs & Risks</h3>
              <p className="text-gray-600">Minimize errors, reduce rework, improve budget accuracy, and proactively identify issues to protect your bottom line.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
              {/* Placeholder for Icon */}
              <div className="text-yellow-500 mb-4 text-4xl">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 mx-auto">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-3.741-5.58M13.5 18.72a9.094 9.094 0 013.741-.479 3 3 0 01-3.741-5.58M13.5 12l-9 5.25L13.5 7l9 5.25-9 5.25z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-700">Improved Collaboration</h3>
              <p className="text-gray-600">Foster seamless information sharing and coordination among stakeholders with a single source of truth for better decisions.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
              {/* Placeholder for Icon */}
              <div className="text-purple-500 mb-4 text-4xl">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 mx-auto">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" />
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-700">Enhanced Quality & Visualization</h3>
              <p className="text-gray-600">Achieve higher quality designs and construction with precise 3D models, clash detection, and clear project visualization.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Section 3: Our Core BIM Services */}
      <section className="py-12 bg-gray-100 rounded-lg shadow-lg">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-semibold mb-10 text-center text-gray-800">Our Core BIM Services</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-2 text-indigo-600">BIM Modeling & Development</h3>
              <p className="text-gray-600 mb-3">From LOD 100 conceptual designs to LOD 400 fabrication-ready models, we create accurate, information-rich BIM representations.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-2 text-indigo-600">BIM Coordination & Clash Detection</h3>
              <p className="text-gray-600 mb-3">We ensure seamless integration of architectural, structural, and MEP systems, identifying and resolving conflicts early.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-2 text-indigo-600">BIM Consulting & Implementation</h3>
              <p className="text-gray-600 mb-3">Our experts guide your BIM adoption, developing strategies and workflows that maximize benefits for your organization.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-xl font-semibold mb-2 text-indigo-600">Specialized BIM Applications</h3>
              <p className="text-gray-600 mb-3">Including 5D cost estimation, 4D scheduling, point cloud to BIM, and custom software development for unique needs.</p>
            </div>
          </div>
          <div className="text-center mt-8">
            <Link href="/services" className="text-indigo-600 hover:text-indigo-800 font-medium transition-colors">
              Explore our full range of services &rarr;
            </Link>
          </div>
        </div>
      </section>

      {/* Section 4: Why Choose Dobson Services? */}
      <section className="py-12">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-semibold mb-6 text-gray-800">Why Choose Dobson Services?</h2>
          <div className="max-w-3xl mx-auto space-y-4">
            <p className="text-lg text-gray-700"><strong className="text-gray-800">Swiss Expertise, Global Reach:</strong> Benefit from Swiss precision and quality, combined with specialized knowledge of CIS and European markets.</p>
            <p className="text-lg text-gray-700"><strong className="text-gray-800">Customer-Centric Approach:</strong> We prioritize your project goals, delivering tailored BIM solutions that provide tangible value and drive success.</p>
            <p className="text-lg text-gray-700"><strong className="text-gray-800">Proven Methodologies:</strong> Our team utilizes industry-leading software and best-practice BIM workflows for optimal results and efficient delivery.</p>
          </div>
        </div>
      </section>

      {/* Section 5: Quick Contact Prompt */}
      <section className="py-16 bg-indigo-600 text-white rounded-lg shadow-xl">
        <div className="container mx-auto text-center px-4">
          <h2 className="text-3xl font-semibold mb-6">Ready to Elevate Your Next Project?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Let's discuss how Dobson Services can help you achieve your objectives with the power of BIM.
          </p>
          <Link href="/contact" className="bg-white text-indigo-700 font-semibold py-3 px-8 rounded-lg hover:bg-gray-100 transition-colors text-lg shadow-md">
            Get a Free Consultation
          </Link>
        </div>
      </section>
    </div>
  );
}

