import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "About Dobson Services | BIM Experts",
  description: "Learn more about Dobson Services, our mission, vision, and expertise in providing BIM solutions in Switzerland, CIS, and Europe.",
};

const SectionTitle = ({ children }: { children: React.ReactNode }) => (
  <h2 className="text-3xl font-semibold mb-6 text-gray-800 pt-8 first:pt-0">{children}</h2>
);

const ValueItem = ({ title, description }: { title: string, description: string }) => (
  <li className="mb-3">
    <strong className="text-indigo-600">{title}:</strong> <span className="text-gray-700 leading-relaxed">{description}</span>
  </li>
);

export default function AboutPage() {
  return (
    <div className="space-y-10 bg-white p-6 md:p-10 rounded-lg shadow-xl">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold text-indigo-700 mb-4">About Dobson Services</h1>
      </header>

      <section>
        <SectionTitle>Our Story / Company Overview</SectionTitle>
        <p className="text-lg text-gray-700 mb-4 leading-relaxed">
          Dobson Services, part of Dobson Consulting, is a Switzerland-based firm specializing in helping companies expand into the CIS region, with a particular focus on the Kyrgyz market. At the same time, we support our Central Asian partners in establishing a strong presence in European markets. Thanks to our knowledge of the market, we bridge opportunities between these regions, ensuring successful growth and expansion for our clients.
        </p>
        <p className="text-lg text-gray-700 leading-relaxed">
          At Dobson Services, we extend this expertise into the realm of Building Information Modeling (BIM). We understand that the successful implementation of advanced technologies like BIM is crucial for modern construction and engineering projects. Our dedicated BIM division leverages the precision, reliability, and innovative spirit synonymous with Swiss enterprise to deliver exceptional BIM services. We are committed to empowering our clients with the tools and insights needed to optimize their projects, reduce risks, and achieve superior outcomes in an increasingly complex global environment.
        </p>
      </section>

      <section className="bg-gray-50 p-8 rounded-lg shadow-md">
        <SectionTitle>Our Mission & Vision</SectionTitle>
        <div className="space-y-6">
          <div>
            <h3 className="text-2xl font-semibold text-gray-700 mb-2">Our Mission:</h3>
            <p className="text-lg text-gray-600 leading-relaxed">
              To be the leading BIM service provider that empowers construction and engineering firms to achieve unparalleled efficiency, quality, and innovation by strategically implementing advanced BIM solutions. We strive to bridge technological and geographical gaps, fostering successful project outcomes and sustainable growth for our clients in Switzerland, the CIS region, and Europe.
            </p>
          </div>
          <div>
            <h3 className="text-2xl font-semibold text-gray-700 mb-2">Our Vision:</h3>
            <p className="text-lg text-gray-600 leading-relaxed">
              To revolutionize the construction and engineering landscape through the transformative power of Building Information Modeling, creating a future where projects are delivered with greater precision, collaboration, and intelligence, contributing to a more sustainable and efficiently built environment worldwide.
            </p>
          </div>
        </div>
      </section>

      <section>
        <SectionTitle>Our Expertise & Values</SectionTitle>
        <ul className="space-y-4">
          <ValueItem 
            title="Cross-Market Expertise"
            description="Our unique strength lies in our deep understanding of both European and CIS markets, particularly Kyrgyzstan. This allows us to provide culturally aware and contextually relevant BIM solutions that navigate regional complexities effectively."
          />
          <ValueItem 
            title="Swiss Precision & Quality"
            description="We uphold the highest standards of quality and precision in every BIM service we deliver, reflecting our Swiss heritage and commitment to excellence."
          />
          <ValueItem 
            title="Innovation & Technology"
            description="We stay at the forefront of BIM technology and methodologies, continuously exploring innovative approaches to deliver cutting-edge solutions that provide a competitive edge."
          />
          <ValueItem 
            title="Client-Centricity"
            description="Our clients are at the heart of everything we do. We listen to your needs, understand your challenges, and tailor our services to ensure your project goals are met and exceeded."
          />
          <ValueItem 
            title="Collaboration & Integrity"
            description="We believe in fostering strong, collaborative partnerships built on trust, transparency, and professional integrity. We work as an extension of your team to achieve shared success."
          />
          <ValueItem 
            title="Knowledge & Empowerment"
            description="We are dedicated to not only providing services but also to empowering our clients and the wider industry through BIM education, training, and knowledge sharing."
          />
        </ul>
      </section>

      <section className="py-10 bg-indigo-600 text-white rounded-lg shadow-xl text-center">
        <SectionTitle>Why Partner with Dobson Services?</SectionTitle>
        <div className="max-w-4xl mx-auto space-y-6 px-4">
          <p className="text-lg leading-relaxed">
            Choosing Dobson Services means partnering with a team that offers:
          </p>
          <ul className="list-disc list-inside space-y-3 text-left md:text-center text-lg">
            <li>Specialized Regional Knowledge: Unmatched expertise in navigating the business and technical landscapes of the CIS region and European markets.</li>
            <li>Comprehensive BIM Capabilities: A full suite of BIM services, from initial modeling (LOD 100) through to advanced fabrication details (LOD 400) and specialized applications like 4D/5D BIM and custom software development.</li>
            <li>A Commitment to Your Success: We are invested in your project&apos;s success, providing dedicated support and tailored solutions to overcome challenges and maximize opportunities.</li>
            <li>A Bridge to New Opportunities: Leveraging our connection with Dobson Consulting, we help you explore and capitalize on cross-regional business prospects.</li>
          </ul>
          <p className="text-xl mt-8 font-semibold">
            We invite you to experience the Dobson Services difference. Let us help you build smarter, faster, and more efficiently with the power of BIM.
          </p>
          <div className="mt-8 space-x-4">
            <Link href="/services" className="bg-white text-indigo-700 font-semibold py-3 px-6 rounded-lg hover:bg-gray-100 transition-colors">
              Discover Our BIM Services
            </Link>
            <Link href="/contact" className="bg-gray-800 text-white font-semibold py-3 px-6 rounded-lg hover:bg-gray-700 transition-colors">
              Discuss Your Project Needs
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

