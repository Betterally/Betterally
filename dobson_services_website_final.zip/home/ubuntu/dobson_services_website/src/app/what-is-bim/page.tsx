import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "What is BIM? | Dobson Services",
  description: "Learn about Building Information Modeling (BIM), BIM maturity levels, and Levels of Development (LOD) with Dobson Services.",
};

const SectionTitle = ({ children }: { children: React.ReactNode }) => (
  <h2 className="text-3xl font-semibold mb-6 text-gray-800 pt-8 first:pt-0">{children}</h2>
);

const SubSectionTitle = ({ children }: { children: React.ReactNode }) => (
  <h3 className="text-2xl font-semibold mb-4 text-gray-700 mt-6">{children}</h3>
);

const ListItem = ({ children }: { children: React.ReactNode }) => (
  <li className="mb-2 text-gray-600 leading-relaxed">{children}</li>
);

export default function WhatIsBimPage() {
  return (
    <div className="space-y-8 bg-white p-6 md:p-10 rounded-lg shadow-xl">
      <h1 className="text-4xl font-bold mb-8 text-center text-indigo-700">What is Building Information Modeling (BIM)?</h1>

      <section>
        <SectionTitle>Defining BIM</SectionTitle>
        <p className="text-lg text-gray-700 mb-4 leading-relaxed">
          Building Information Modeling (BIM) is a transformative process and technology that revolutionizes how buildings and infrastructure are designed, constructed, and managed. At its core, BIM is the creation and use of an intelligent 3D model to inform and communicate project decisions. This digital representation encompasses the physical and functional characteristics of a facility, serving as a shared knowledge resource for reliable information throughout a project&apos;s lifecycle – from the earliest concept to demolition.
        </p>
        <p className="text-lg text-gray-700 mb-6 leading-relaxed">
          BIM is more than just software or a 3D model; it&apos;s a collaborative methodology. It enables architects, engineers, contractors, and owners to work together more effectively, integrating multi-disciplinary data into a single, coordinated model. This fosters better understanding, improved efficiency, and higher quality outcomes.
        </p>

        <SubSectionTitle>What BIM is NOT:</SubSectionTitle>
        <p className="text-gray-700 mb-4 leading-relaxed">
          It&apos;s important to clarify common misconceptions about Building Information Modeling:
        </p>
        <ul className="list-disc list-inside space-y-2 pl-4">
          <ListItem>
            <strong>BIM is not just a newer way of 3D modeling:</strong> While 3D modeling is a component, BIM incorporates intelligent data, relationships, and attributes that go far beyond simple geometry.
          </ListItem>
          <ListItem>
            <strong>BIM is not solely for large projects:</strong> BIM offers significant benefits for projects of all sizes, scaling to meet diverse needs and complexities.
          </ListItem>
          <ListItem>
            <strong>BIM is not prohibitively expensive:</strong> While there&apos;s an initial investment, the long-term cost savings from reduced errors, rework, and improved efficiency often result in a strong return on investment.
          </ListItem>
          <ListItem>
            <strong>BIM is not just a software package:</strong> BIM is a process that utilizes various software tools. The tools themselves are enablers of the BIM methodology.
          </ListItem>
          <ListItem>
            <strong>BIM is not overly complex to implement:</strong> With proper planning, training, and phased adoption, BIM can be integrated smoothly into existing workflows.
          </ListItem>
          <ListItem>
            <strong>BIM is not just for design and construction:</strong> The information-rich BIM model provides significant value for facility management, operations, and maintenance throughout the building&apos;s lifecycle.
          </ListItem>
        </ul>
      </section>

      <section>
        <SectionTitle>BIM Maturity Levels</SectionTitle>
        <p className="text-gray-700 mb-4 leading-relaxed">
          BIM implementation can be understood through different maturity levels, which describe the degree of collaboration and information sharing among project stakeholders:
        </p>
        <ul className="space-y-4">
          <li>
            <h4 className="text-xl font-semibold text-gray-700 mb-1">BIM Level 0 (Low Collaboration):</h4>
            <p className="text-gray-600 leading-relaxed">Characterized by 2D CAD drafting, primarily using paper-based or non-interoperable digital information exchange. There is little to no collaboration between disciplines using shared models.</p>
          </li>
          <li>
            <h4 className="text-xl font-semibold text-gray-700 mb-1">BIM Level 1 (Partial Collaboration):</h4>
            <p className="text-gray-600 leading-relaxed">Involves a mix of 2D and 3D CAD work. A Common Data Environment (CDE) might be used for sharing files, but models are typically not shared between different disciplines in a collaborative way. Focus is on managing CAD data with some standardized approaches.</p>
          </li>
          <li>
            <h4 className="text-xl font-semibold text-gray-700 mb-1">BIM Level 2 (Full Collaboration):</h4>
            <p className="text-gray-600 leading-relaxed">This level involves collaborative working. All parties use their own 3D CAD models, but all project information is shared through a common file format (like IFC or COBie). The CDE is crucial here, enabling teams to work with federated models that combine inputs from various disciplines. This level introduces 4D (time/scheduling) and 5D (cost) BIM capabilities.</p>
          </li>
          <li>
            <h4 className="text-xl font-semibold text-gray-700 mb-1">BIM Level 3 (Full Integration):</h4>
            <p className="text-gray-600 leading-relaxed">Represents the ultimate goal for BIM adoption. It involves a fully integrated and interoperable approach, where all project data resides in a single, shared project model stored in a centralized repository (often cloud-based). All stakeholders can access and modify the same model, and changes are reflected in real-time. This level supports full lifecycle management of a facility.</p>
          </li>
        </ul>
        <p className="text-gray-700 mt-4 leading-relaxed">
          Dobson Services helps clients navigate these maturity levels, implementing solutions appropriate for their current capabilities and future aspirations.
        </p>
      </section>

      <section>
        <SectionTitle>Levels of Development (LOD)</SectionTitle>
        <p className="text-gray-700 mb-4 leading-relaxed">
          Level of Development (LOD) specifications define the extent to which a model element has been developed and the reliability of the information it contains. LOD allows professionals to clearly articulate and specify the content of BIM at various stages of the design and construction process. Here are the common LOD stages:
        </p>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-gray-50 p-4 rounded-md shadow">
            <h4 className="text-lg font-semibold text-indigo-600 mb-1">LOD 100 (Conceptual):</h4>
            <p className="text-gray-600 text-sm leading-relaxed">The model element is represented with a symbol or other generic representation. Information is conceptual; for example, a building mass showing overall volume, area, height, and orientation. Analysis is based on area and volume.</p>
          </div>
          <div className="bg-gray-50 p-4 rounded-md shadow">
            <h4 className="text-lg font-semibold text-indigo-600 mb-1">LOD 200 (Approximate Geometry / Design Development):</h4>
            <p className="text-gray-600 text-sm leading-relaxed">The model element is graphically represented as a generic system, object, or assembly with approximate quantities, size, shape, location, and orientation. Non-geometric information may also be attached. This level is suitable for general design and coordination.</p>
          </div>
          <div className="bg-gray-50 p-4 rounded-md shadow">
            <h4 className="text-lg font-semibold text-indigo-600 mb-1">LOD 300 (Precise Geometry / Construction Documents):</h4>
            <p className="text-gray-600 text-sm leading-relaxed">The model element is graphically represented with specific assemblies, accurate in quantity, size, shape, location, and orientation. Non-geometric information attached to the model element is also precise. This is the level typically required for construction documentation and shop drawings.</p>
          </div>
          <div className="bg-gray-50 p-4 rounded-md shadow">
            <h4 className="text-lg font-semibold text-indigo-600 mb-1">LOD 350 (Precise Geometry with Connections / Coordination):</h4>
            <p className="text-gray-600 text-sm leading-relaxed">This level includes model elements with details necessary for coordination with other disciplines, such as supports and connections. It clarifies how elements interface with various systems.</p>
          </div>
          <div className="bg-gray-50 p-4 rounded-md shadow">
            <h4 className="text-lg font-semibold text-indigo-600 mb-1">LOD 400 (Fabrication-ready Geometry / Fabrication & Assembly):</h4>
            <p className="text-gray-600 text-sm leading-relaxed">The model element is modeled with sufficient detail and accuracy for fabrication and assembly. This includes specific information on manufacturing, assembly, and installation.</p>
          </div>
          <div className="bg-gray-50 p-4 rounded-md shadow">
            <h4 className="text-lg font-semibold text-indigo-600 mb-1">LOD 500 (Operational / As-Built Models):</h4>
            <p className="text-gray-600 text-sm leading-relaxed">The model elements are as-constructed representations, verified in terms of size, shape, location, quantity, and orientation. This level is used for maintenance, operations, and facility management.</p>
          </div>
        </div>
        <p className="text-gray-700 mt-6 leading-relaxed">
          Understanding and specifying the required LOD at each project phase is crucial for effective BIM execution. Dobson Services provides expertise in developing models to the appropriate LOD to meet your project&apos;s specific requirements, ensuring clarity and precision from LOD 100 through LOD 400.
        </p>
      </section>

      <section>
        <SectionTitle>The Power of Information in BIM</SectionTitle>
        <p className="text-lg text-gray-700 leading-relaxed">
          While the 3D visualization aspect of BIM is powerful, the true strength of Building Information Modeling lies in the &quot;I&quot; – Information. Each element in a BIM model is not just a geometric shape but an intelligent object containing a wealth of data. This data can include material properties, manufacturer details, cost, installation schedules, performance characteristics, and maintenance requirements. This rich, integrated information empowers better decision-making, enhances analysis capabilities, and provides lasting value throughout the entire lifecycle of a built asset.
        </p>
      </section>
    </div>
  );
}

