"use client";

import { useState, FormEvent } from "react";

// Removed metadata export as it should not be in a client component
// export const metadata: Metadata = {
//   title: "Contact Us | Dobson Services",
//   description: "Get in touch with Dobson Services for your BIM needs. Contact us via form, email, or phone.",
// };

const SectionTitle = ({ children }: { children: React.ReactNode }) => (
  <h2 className="text-3xl font-semibold mb-6 text-gray-800 pt-8 first:pt-0">{children}</h2>
);

export default function ContactPage() {
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    company: "",
    subject: "",
    message: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    // Placeholder for actual form submission logic
    // For now, we just simulate a successful submission
    console.log("Form data submitted:", formData);
    setFormSubmitted(true);
    // Reset form after a delay (optional)
    setTimeout(() => {
        setFormSubmitted(false);
        setFormData({
            fullName: "",
            email: "",
            company: "",
            subject: "",
            message: "",
        });
    }, 5000); 
  };

  return (
    <div className="space-y-10 bg-white p-6 md:p-10 rounded-lg shadow-xl">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold text-indigo-700 mb-4">Get in Touch</h1>
        <p className="text-lg text-gray-700 max-w-3xl mx-auto leading-relaxed">
          We are eager to hear from you! Whether you have a specific project in mind, a question about our BIM services, or wish to explore how Dobson Services can help your company leverage the power of Building Information Modeling, please don&apos;t hesitate to reach out. Our team is ready to provide the information and support you need.
        </p>
      </header>

      <div className="grid md:grid-cols-2 gap-12 items-start">
        {/* Section 1: Send Us a Message (Contact Form) */}
        <section>
          <SectionTitle>Send Us a Message</SectionTitle>
          <p className="text-gray-700 mb-6 leading-relaxed">
            Use the form below to send us a direct message. We aim to respond to all inquiries promptly.
          </p>
          {formSubmitted ? (
            <div className="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded-md shadow-md" role="alert">
              <p className="font-bold">Message Sent!</p>
              <p>Thank you for your message! We have received your inquiry and a member of our team will get back to you as soon as possible.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 mb-1">Full Name <span className="text-red-500">*</span></label>
                <input type="text" name="fullName" id="fullName" value={formData.fullName} onChange={handleChange} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email Address <span className="text-red-500">*</span></label>
                <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
              </div>
              <div>
                <label htmlFor="company" className="block text-sm font-medium text-gray-700 mb-1">Company Name</label>
                <input type="text" name="company" id="company" value={formData.company} onChange={handleChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
              </div>
              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">Subject</label>
                <input type="text" name="subject" id="subject" value={formData.subject} onChange={handleChange} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm" />
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">Your Message <span className="text-red-500">*</span></label>
                <textarea name="message" id="message" value={formData.message} onChange={handleChange} rows={4} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"></textarea>
              </div>
              <div>
                <button type="submit" className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors">
                  Send Message
                </button>
              </div>
            </form>
          )}
        </section>

        {/* Section 2: Direct Contact Details */}
        <section>
          <SectionTitle>Direct Contact Details</SectionTitle>
          <p className="text-gray-700 mb-6 leading-relaxed">
            Alternatively, you can reach us through the following channels:
          </p>
          <div className="space-y-4 text-gray-700">
            <p>
              <strong className="text-gray-800">Email:</strong> <a href="mailto:info@dobson-services.com" className="text-indigo-600 hover:text-indigo-800 transition-colors">info@dobson-services.com</a>
            </p>
            <p>
              <strong className="text-gray-800">Phone:</strong> <a href="tel:+41766157932" className="text-indigo-600 hover:text-indigo-800 transition-colors">+41 76 615 79 32</a>
            </p>
            <p>
              <strong className="text-gray-800">Business Hours:</strong> Monday - Friday: 09:00 - 17:00 CET (Central European Time)
            </p>
            <div>
              <strong className="text-gray-800">Office Address:</strong>
              <address className="not-italic mt-1">
                Dobson Services<br />
                [Placeholder for Street Address]<br />
                [Placeholder for Postal Code & City]<br />
                Switzerland
              </address>
            </div>
          </div>

          {/* Section 3: Our Location (Optional Map Placeholder) */}
          <div className="mt-10">
            <h3 className="text-2xl font-semibold text-gray-700 mb-3">Our Location</h3>
            <div className="bg-gray-200 h-64 rounded-md flex items-center justify-center text-gray-500 shadow">
              Map Placeholder (e.g., Embedded Google Map)
            </div>
          </div>

        </section>
      </div>
      <p className="text-center text-lg text-gray-700 mt-12 leading-relaxed">
         We look forward to connecting with you and exploring how our BIM expertise can contribute to your success.
      </p>
    </div>
  );
}

