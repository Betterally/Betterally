import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "BIM in Real Life | Case Studies | Dobson Services",
  description: "Explore real-world case studies showcasing the impact and benefits of Building Information Modeling (BIM) in various projects.",
};

const SectionTitle = ({ children }: { children: React.ReactNode }) => (
  <h2 className="text-3xl font-semibold mb-8 text-gray-800 pt-8 first:pt-0">{children}</h2>
);

interface CaseStudyProps {
  title: string;
  projectType: string;
  challenge: string;
  solution: string;
  outcomes: string[];
  // visualPlaceholder: string; // For image alt text or future image component
}

const CaseStudyCard = ({ title, projectType, challenge, solution, outcomes }: CaseStudyProps) => (
  <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow mb-8">
    <div className="mb-4 h-48 bg-gray-200 rounded-md flex items-center justify-center text-gray-500">
      {/* Placeholder for actual image/visual */}
      Visual Placeholder for {title}
    </div>
    <h3 className="text-2xl font-semibold text-indigo-700 mb-2">{title}</h3>
    <p className="text-sm text-gray-500 mb-3"><em>Project Type: {projectType}</em></p>
    <div className="space-y-3 text-gray-700 leading-relaxed">
      <p><strong className="text-gray-800">Challenge:</strong> {challenge}</p>
      <p><strong className="text-gray-800">BIM Solution:</strong> {solution}</p>
      <div>
        <strong className="text-gray-800">Outcome/Results:</strong>
        <ul className="list-disc list-inside pl-4 mt-1 space-y-1">
          {outcomes.map((outcome, index) => (
            <li key={index}>{outcome}</li>
          ))}
        </ul>
      </div>
    </div>
  </div>
);

const caseStudiesData: CaseStudyProps[] = [
  {
    title: "Optimizing Office Space with BIM Data Management",
    projectType: "Commercial Office Space Development (Inspired by WeWork's approach)",
    challenge: "Maximizing space utilization and streamlining the design-to-construction workflow for rapidly deployable, flexible office environments.",
    solution: "Detailed 3D BIM models were created to simulate various layouts and configurations before physical construction. This involved integrating architectural and interior design elements with MEP systems within the BIM environment. Data management protocols ensured all stakeholders accessed up-to-date information, facilitating rapid design iterations and coordination.",
    outcomes: [
      "Enhanced Space Efficiency: Achieved a significant increase (e.g., 15-20% reported in similar cases) in usable space through meticulous planning and layout optimization within the BIM model.",
      "Reduced Errors & Rework: Early identification of potential design and spatial conflicts minimized costly changes during the construction phase.",
      "Accelerated Project Delivery: Streamlined design and coordination processes led to faster project completion times, allowing for quicker occupancy and revenue generation.",
      "Improved Collaboration: The centralized BIM model served as a common platform for architects, engineers, and contractors, fostering better communication and more coordinated efforts."
    ]
  },
  {
    title: "Iconic Skyscraper Realized with Architectural & HVAC BIM",
    projectType: "High-Rise Mixed-Use Tower (Inspired by Shanghai Tower)",
    challenge: "Designing and constructing a supertall, architecturally complex building with unique structural and MEP system requirements, demanding exceptional coordination among numerous stakeholders.",
    solution: "Comprehensive BIM implementation was central to the project. Architectural BIM modeling allowed for intricate design development and visualization. HVAC BIM modeling was crucial for designing and simulating the performance of complex airflow and energy-efficient climate control systems tailored to the building's unique form and mixed-use nature. Advanced clash detection was employed across all disciplines.",
    outcomes: [
      "Enhanced Design Visualization & Decision-Making: Detailed 3D models provided stakeholders with a clear understanding of the building's complex design, facilitating informed approvals.",
      "Improved Multidisciplinary Coordination: BIM enabled seamless collaboration, significantly reducing design conflicts between architectural, structural, and MEP systems (e.g., 30% reduction in design errors reported in similar cases).",
      "Optimized Energy Efficiency: BIM facilitated the integration of energy-saving HVAC strategies and facade designs, contributing to substantial long-term operational cost reductions (e.g., 21% energy cost reduction cited).",
      "Construction Efficiency: The precision and coordination achieved through BIM led to notable improvements in construction efficiency and reductions in overall construction costs compared to traditional methods."
    ]
  },
  {
    title: "Infrastructure Modernization with Point Cloud to BIM",
    projectType: "Renovation of a Major Transportation Hub (Inspired by Sydney Opera House Digital Twin / Airport Renovations)",
    challenge: "Modernizing and renovating a complex, historically significant structure with incomplete or outdated existing documentation, requiring precise as-built information without disrupting ongoing operations or damaging sensitive architecture.",
    solution: "Laser scanning (LiDAR) was used to capture highly accurate 3D point cloud data of the existing facility. This point cloud data was then processed and converted into an intelligent as-built BIM model. This model served as the precise foundation for planning renovations, coordinating new installations with existing structures, and managing facility assets.",
    outcomes: [
      "Accurate As-Built Documentation: Created a precise digital twin of the existing structure, overcoming the limitations of outdated or missing drawings.",
      "Non-Invasive Surveying: Avoided damage to historic or delicate architectural elements during the documentation process.",
      "Improved Renovation Planning & Coordination: The accurate BIM model allowed designers and contractors to precisely plan interventions, detect potential clashes, and optimize new system integrations.",
      "Reduced Rework & On-Site Surprises: Minimized unforeseen issues during construction by working from a reliable as-built model.",
      "Enhanced Facility Management: The resulting BIM model provides a valuable, long-term asset for ongoing maintenance, operations, and future modifications."
    ]
  },
  {
    title: "Prefabrication and Digital Construction for Large-Scale Infrastructure",
    projectType: "Major Infrastructure Project (Inspired by Crossrail, London)",
    challenge: "Managing the immense complexity, tight schedule, and stringent budget of a large-scale infrastructure project involving multiple contractors and extensive off-site manufacturing.",
    solution: "BIM was integral to the project, enabling 4D modeling for construction sequencing and logistics planning. It facilitated the precise design and manufacturing of prefabricated components, ensuring accurate fit-up on site. A common data environment (CDE) was used for real-time collaboration and information sharing among all project partners.",
    outcomes: [
      "Optimized Construction Sequencing (4D BIM): Visual planning of construction activities improved site logistics and reduced potential delays.",
      "Enhanced Prefabrication Accuracy: BIM models provided exact specifications for off-site manufacturing, minimizing errors and improving the quality of prefabricated elements.",
      "Significant Cost Savings: By avoiding on-site delays, reducing errors, and optimizing material use through BIM-driven prefabrication, substantial cost savings were achieved (e.g., estimates of 10% savings on similar large projects).",
      "Improved Project Control & Collaboration: The CDE and shared BIM models provided a single source of truth, enhancing coordination and decision-making across the vast project team."
    ]
  }
];

export default function BimInRealLifePage() {
  return (
    <div className="space-y-10 bg-white p-6 md:p-10 rounded-lg shadow-xl">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold text-indigo-700 mb-4">BIM in Action: Real-World Success Stories</h1>
        <p className="text-lg text-gray-700 max-w-3xl mx-auto leading-relaxed">
          Building Information Modeling isn&apos;t just a theoretical concept; it&apos;s a practical methodology delivering tangible results on projects worldwide. At Dobson Services, we believe in showcasing the real-world impact of BIM. Explore these examples to see how BIM, and approaches similar to those we champion, can transform project outcomes, enhance collaboration, and drive efficiency.
        </p>
      </header>

      <section>
        <div className="grid md:grid-cols-1 lg:grid-cols-2 gap-10">
          {caseStudiesData.map((study) => (
            <CaseStudyCard key={study.title} {...study} />
          ))}
        </div>
      </section>

      <section className="mt-12 text-center py-8 bg-gray-100 rounded-lg shadow-md">
        <p className="text-lg text-gray-700 max-w-3xl mx-auto mb-6 leading-relaxed">
          These examples illustrate the power and versatility of BIM. Dobson Services can help apply these principles and our expertise to ensure the success of your specific projects.
        </p>
        <Link href="/contact" className="bg-indigo-600 text-white font-semibold py-3 px-8 rounded-lg hover:bg-indigo-700 transition-colors text-lg shadow-md">
          Contact Us to Learn More
        </Link>
      </section>
    </div>
  );
}

