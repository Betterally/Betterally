import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Why Use BIM? | Dobson Services",
  description: "Discover the compelling advantages of Building Information Modeling (BIM) for your construction and engineering projects with Dobson Services.",
};

const SectionTitle = ({ children }: { children: React.ReactNode }) => (
  <h2 className="text-3xl font-semibold mb-8 text-gray-800 pt-8 first:pt-0">{children}</h2>
);

const BenefitCategory = ({ title, children }: { title: string, children: React.ReactNode }) => (
  <div className="mb-8">
    <h3 className="text-2xl font-semibold text-indigo-700 mb-4">{title}</h3>
    <ul className="list-disc list-inside space-y-3 pl-4 text-gray-700 leading-relaxed">
      {children}
    </ul>
  </div>
);

const BenefitItem = ({ title, description }: { title: string, description: string }) => (
  <li>
    <strong>{title}:</strong> {description}
  </li>
);

export default function WhyUseBimPage() {
  return (
    <div className="space-y-10 bg-white p-6 md:p-10 rounded-lg shadow-xl">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold text-indigo-700 mb-4">The Advantages of BIM: Why Your Project Needs It</h1>
        <p className="text-lg text-gray-700 max-w-3xl mx-auto leading-relaxed">
          Building Information Modeling (BIM) is not just a technological trend; it&apos;s a fundamental shift that is reshaping the Architecture, Engineering, and Construction (AEC) industry. Adopting BIM offers a multitude of compelling advantages that translate into tangible benefits for your projects, your team, and your bottom line. Dobson Services helps you unlock these benefits, ensuring your projects are delivered faster, more economically, and with higher quality.
        </p>
      </header>

      <section>
        <SectionTitle>Core Benefits of Implementing BIM</SectionTitle>
        <p className="text-lg text-gray-700 mb-8 leading-relaxed">
          Embracing BIM brings transformative improvements across every phase of a project lifecycle. Here’s how:
        </p>

        <div className="grid md:grid-cols-1 lg:grid-cols-2 gap-x-12 gap-y-8">
          <BenefitCategory title="Significant Cost Savings & Financial Control">
            <BenefitItem title="Reduced Overall Project Costs" description="BIM enables more efficient processes and reduces errors, leading to potential project cost reductions of up to 20%." />
            <BenefitItem title="Minimized Design Errors" description="Early clash detection and model-based reviews can cut design errors by 50-60%, drastically decreasing the need for expensive changes during construction." />
            <BenefitItem title="Lower Rework Costs" description="By identifying and resolving conflicts in the digital model before construction begins, rework costs can be slashed by 40-50%." />
            <BenefitItem title="Optimized Material Usage" description="Accurate quantity take-offs from the BIM model lead to precise material estimation, reducing construction waste by 4-15%." />
            <BenefitItem title="Operational Cost Efficiency" description="The detailed information within a BIM model supports better facility management, potentially saving around 5% annually in operational costs." />
            <BenefitItem title="Enhanced Budget Forecasting" description="5D BIM integrates cost data directly with the model, allowing for real-time cost feedback and more accurate budget control throughout the project." />
          </BenefitCategory>

          <BenefitCategory title="Accelerated Timelines & Increased Time Efficiency">
            <BenefitItem title="Faster Design Processes" description="BIM facilitates quicker design iterations and automates aspects of documentation, potentially reducing design time by up to 15%." />
            <BenefitItem title="Streamlined Construction Sequencing" description="4D BIM links the 3D model with the project schedule, optimizing construction planning and logistics." />
            <BenefitItem title="Reduced Coordination Time" description="Automated clash detection replaces time-consuming manual reviews, speeding up the coordination process among disciplines." />
            <BenefitItem title="Minimized Delays" description="Proactive issue identification and resolution prevent problems from escalating and causing schedule disruptions." />
          </BenefitCategory>

          <BenefitCategory title="Improved Quality, Accuracy & Visualization">
            <BenefitItem title="Enhanced Visualization" description="Realistic 3D models allow all stakeholders, including non-technical ones, to clearly understand the design intent, leading to better-informed decisions and approvals." />
            <BenefitItem title="Superior Coordination" description="BIM ensures that all building systems (architectural, structural, MEP) are designed and integrated harmoniously, preventing on-site clashes." />
            <BenefitItem title="Fewer RFIs and Change Orders" description="The clarity and completeness of BIM models significantly reduce the number of Requests for Information (RFIs) and costly change orders during construction." />
            <BenefitItem title="Better Constructability Analysis" description="Virtual construction simulations help identify and resolve potential buildability issues before they arise in the field." />
            <BenefitItem title="Accurate As-Built Documentation" description="BIM provides a precise digital record of the completed project, invaluable for facility management and future renovations." />
          </BenefitCategory>

          <BenefitCategory title="Comprehensive Risk Reduction & Mitigation">
            <BenefitItem title="Early Issue Identification" description="Design flaws and interdisciplinary conflicts are detected in the digital environment, long before they become expensive field problems." />
            <BenefitItem title="Improved Safety Planning" description="Construction processes can be simulated within the BIM environment to identify potential hazards and plan safer work sequences." />
            <BenefitItem title="Reduced Liability Exposure" description="Comprehensive documentation, improved quality control, and fewer errors contribute to a lower risk profile for all project stakeholders." />
          </BenefitCategory>

          <BenefitCategory title="Enhanced Collaboration & Communication">
            <BenefitItem title="Centralized Information Sharing" description="A Common Data Environment (CDE) ensures that everyone is working from the same current and accurate information, creating a single source of truth." />
            <BenefitItem title="Improved Interdisciplinary Coordination" description="BIM fosters a collaborative environment where architects, engineers, and contractors can work together more effectively on integrated models." />
            <BenefitItem title="Clearer Communication" description="Visualizations and shared models reduce misunderstandings and improve the clarity of communication regarding design intent and project status." />
          </BenefitCategory>

          <BenefitCategory title="Lifecycle Benefits Beyond Construction">
            <BenefitItem title="Efficient Facility Management" description="The BIM model serves as a comprehensive digital asset, containing detailed information about building components, crucial for maintenance and operations." />
            <BenefitItem title="Simplified Renovations and Retrofits" description="Accurate as-built models make planning for future modifications much more straightforward and less risky." />
            <BenefitItem title="Support for Sustainability" description="BIM enables energy analysis, daylighting studies, and sustainable material selection, contributing to greener building designs and operations." />
          </BenefitCategory>
        </div>
      </section>

      <section>
        <SectionTitle>The Competitive Edge with BIM</SectionTitle>
        <p className="text-lg text-gray-700 mb-6 leading-relaxed">
          In today’s increasingly competitive market, BIM capabilities are no longer a luxury but a necessity:
        </p>
        <ul className="list-disc list-inside space-y-3 pl-4 text-gray-700 leading-relaxed">
          <li>Meet Client Expectations: Clients are increasingly demanding the efficiency, quality, and transparency that BIM delivers.</li>
          <li>Industry Leadership: Adopting BIM positions your firm as forward-thinking and technologically advanced.</li>
          <li>Win More Projects: Many government and private sector tenders now mandate BIM usage.</li>
          <li>Attract Top Talent: Professionals are drawn to companies that utilize cutting-edge tools and processes.</li>
        </ul>
      </section>

      <section className="text-center py-8 bg-gray-100 rounded-lg shadow-md">
        <h2 className="text-3xl font-semibold text-gray-800 mb-4">Embrace the Future with Dobson Services</h2>
        <p className="text-lg text-gray-700 max-w-3xl mx-auto mb-6 leading-relaxed">
          The evidence is undeniable: Building Information Modeling offers profound benefits that can transform your project outcomes. From substantial cost and time savings to enhanced quality and collaboration, BIM is essential for success in the modern construction landscape. Dobson Services is your expert partner in navigating the BIM journey, ensuring you leverage its full potential to build better, faster, and smarter.
        </p>
        <div className="space-x-4">
          <Link href="/services" className="bg-indigo-600 text-white font-semibold py-3 px-6 rounded-lg hover:bg-indigo-700 transition-colors">
            Explore Our Services
          </Link>
          <Link href="/contact" className="bg-gray-600 text-white font-semibold py-3 px-6 rounded-lg hover:bg-gray-700 transition-colors">
            Contact Us Today
          </Link>
        </div>
      </section>
    </div>
  );
}

